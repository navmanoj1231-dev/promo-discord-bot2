# Promo Discord Bot

A Discord.js v14 bot based on the supplied promo-command screenshot. It supports:
- `/accounts` — register/edit two TikTok account names or profile URLs.
- `/submit` — submit a TikTok video URL and current view count for staff review.
- `/progress` — show approved monthly views, posts, tracked invites, and quota progress.
- `/goal` — set personal monthly goals for views, posts, and invites.
- `/leaderboard by:invites|views` — top 10 promoters.
- `/newinvite` — create a permanent tracked invite link; older links remain tracked.
- `/staff` — send a message to the configured staff channel or staff-role members by DM.
- `/admin pending|approve|reject|setviews|quota|member|removeaccount|reset` — staff moderation and management.

## Important behavior and limitations

1. TikTok view counts are **manual**. A promoter submits the URL and reported view count; staff approve or reject it. The bot does not claim to read TikTok analytics automatically.
2. The bot counts approved submissions and tracked invite joins for the current calendar month (UTC, based on the database server clock).
3. `/admin setviews` adds a staff-approved adjustment record. It does not overwrite previous submissions.
4. Invite attribution uses Discord invite-use deltas. For reliable tracking, enable the **Guild Members** and **Guild Invites** privileged gateway intents in the Discord Developer Portal, and give the bot **Manage Server** permission. Vanity URL joins, one-time race conditions, and joins where Discord does not expose a changed invite cannot be attributed reliably.
5. `/newinvite` needs the bot to have **Create Invite** permission in the channel where the command is run.
6. The bot uses SQLite. For cloud hosting, use a persistent disk/volume mounted to the app's `data/` directory. Do not deploy on ephemeral storage or data will be lost on restart/redeploy.
7. `/admin reset` removes current-month submissions and invite-use records. Use it only at the start of a new quota period; it does not clear account registrations or goals.

## Setup

### 1. Create the Discord application
- In the Discord Developer Portal, create an application and add a Bot.
- Copy the bot token and Application ID.
- Under **Bot → Privileged Gateway Intents**, enable **Server Members Intent**. Invite tracking also requires the bot to have access to server invites (Manage Server permission).
- Invite the bot with scopes `bot` and `applications.commands`.
- Suggested permissions: View Channels, Send Messages, Embed Links, Read Message History, Create Invite, Manage Server (for invite tracking).

### 2. Configure environment
Copy `.env.example` to `.env`, then set:
- `DISCORD_TOKEN`
- `CLIENT_ID`
- `GUILD_ID`
- `STAFF_ROLE_IDS` (comma-separated role IDs)
- optional `STAFF_CHANNEL_ID` and `LOG_CHANNEL_ID`

Never share your bot token or commit `.env`.

### 3. Install and register commands
Requires Node.js 20 or newer.

```bash
npm install
npm run register
npm start
```

Guild slash commands normally appear quickly after registration.

### 4. Cloud deployment
Use a Node.js worker/service on a host that supports persistent storage:
- Build/install command: `npm install`
- Start command: `npm start`
- Persistent volume mount: project `data/` directory
- Environment variables: copy the values from `.env` into the host's secret/environment settings

Keep one running bot instance for this SQLite setup. Do not run multiple replicas against the same SQLite file.

## Recommended server permissions
- Regular members: View Channel + Read Message History; deny Send Messages if the server is read-only.
- Bot role: View Channels, Send Messages, Embed Links, Read Message History, Create Invite, and Manage Server for invite attribution.
- Staff role IDs: add your staff/admin role IDs to `STAFF_ROLE_IDS`.
- Keep the bot role below roles it should not manage. This bot does not grant roles or change member permissions.

## Suggested next upgrades
- Monthly scheduled reset with timezone-aware billing/quota cycles.
- Submission proof attachments and staff approve/reject buttons.
- Separate per-account totals and all-time leaderboards.
- Anti-duplicate URL checks and editable submission corrections.
- Exportable CSV reports.
