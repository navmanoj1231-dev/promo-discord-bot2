require("dotenv").config();

function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`Missing ${name}. Copy .env.example to .env and configure it.`);
  return value;
}

module.exports = {
  token: required("DISCORD_TOKEN"),
  clientId: required("CLIENT_ID"),
  guildId: required("GUILD_ID"),
  staffRoleIds: (process.env.STAFF_ROLE_IDS || "").split(",").map(x => x.trim()).filter(Boolean),
  staffChannelId: process.env.STAFF_CHANNEL_ID || "",
  logChannelId: process.env.LOG_CHANNEL_ID || ""
};
