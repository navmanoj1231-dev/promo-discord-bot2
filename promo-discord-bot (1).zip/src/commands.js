const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

const commands = [
  new SlashCommandBuilder().setName("accounts").setDescription("Register or view your two TikTok accounts"),
  new SlashCommandBuilder().setName("progress").setDescription("See your views, posts, invites and quota progress"),
  new SlashCommandBuilder().setName("goal").setDescription("Set your personal promoter targets")
    .addIntegerOption(o => o.setName("views").setDescription("Monthly approved view target").setMinValue(0))
    .addIntegerOption(o => o.setName("posts").setDescription("Monthly approved post target").setMinValue(0))
    .addIntegerOption(o => o.setName("invites").setDescription("Monthly invite target").setMinValue(0)),
  new SlashCommandBuilder().setName("leaderboard").setDescription("Rank promoters by invites or total views")
    .addStringOption(o => o.setName("by").setDescription("What to rank by").addChoices(
      { name: "Invites", value: "invites" }, { name: "Total views", value: "views" }
    )),
  new SlashCommandBuilder().setName("newinvite").setDescription("Create a personal tracked invite link"),
  new SlashCommandBuilder().setName("staff").setDescription("Send a private message to the promo staff")
    .addStringOption(o => o.setName("message").setDescription("Your question or update").setRequired(true).setMaxLength(1000)),
  new SlashCommandBuilder().setName("submit").setDescription("Submit a TikTok video and view count for staff verification")
    .addStringOption(o => o.setName("account").setDescription("Which registered account").setRequired(true)
      .addChoices({name:"Account 1",value:"1"},{name:"Account 2",value:"2"}))
    .addStringOption(o => o.setName("video_url").setDescription("TikTok video URL").setRequired(true))
    .addIntegerOption(o => o.setName("views").setDescription("Current view count").setRequired(true).setMinValue(0)),
  new SlashCommandBuilder().setName("admin").setDescription("Staff tools")
    .addSubcommand(s => s.setName("pending").setDescription("List pending view submissions"))
    .addSubcommand(s => s.setName("approve").setDescription("Approve a submission")
      .addIntegerOption(o => o.setName("id").setDescription("Submission ID").setRequired(true)))
    .addSubcommand(s => s.setName("reject").setDescription("Reject a submission")
      .addIntegerOption(o => o.setName("id").setDescription("Submission ID").setRequired(true)))
    .addSubcommand(s => s.setName("setviews").setDescription("Set a promoter's monthly approved view total")
      .addUserOption(o => o.setName("member").setDescription("Promoter").setRequired(true))
      .addIntegerOption(o => o.setName("views").setDescription("Correct total views").setRequired(true).setMinValue(0)))
    .addSubcommand(s => s.setName("quota").setDescription("Set a promoter's monthly quota")
      .addUserOption(o => o.setName("member").setDescription("Promoter").setRequired(true))
      .addIntegerOption(o => o.setName("views").setDescription("View quota"))
      .addIntegerOption(o => o.setName("posts").setDescription("Post quota"))
      .addIntegerOption(o => o.setName("invites").setDescription("Invite quota")))
    .addSubcommand(s => s.setName("member").setDescription("View a promoter's stats")
      .addUserOption(o => o.setName("member").setDescription("Promoter").setRequired(true)))
    .addSubcommand(s => s.setName("removeaccount").setDescription("Remove one registered TikTok account")
      .addUserOption(o => o.setName("member").setDescription("Promoter").setRequired(true))
      .addIntegerOption(o => o.setName("slot").setDescription("Account slot (1 or 2)").setRequired(true).addChoices(
        {name:"Account 1",value:1},{name:"Account 2",value:2}
      )))
    .addSubcommand(s => s.setName("reset").setDescription("Reset all monthly totals and quotas for the new month")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator))
].map(c => c.toJSON());

module.exports = commands;
