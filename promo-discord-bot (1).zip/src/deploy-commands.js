const { REST, Routes } = require("discord.js");
const config = require("./config");
const commands = require("./commands");

(async () => {
  const rest = new REST({ version: "10" }).setToken(config.token);
  await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), { body: commands });
  console.log(`Registered ${commands.length} guild slash commands.`);
})().catch(err => { console.error(err); process.exit(1); });
