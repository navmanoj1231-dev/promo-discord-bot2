const {
  Client, GatewayIntentBits, Partials, EmbedBuilder, Events, MessageFlags
} = require("discord.js");
const db = require("./db");
const config = require("./config");

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildInvites],
  partials: [Partials.GuildMember]
});

const q = {
  promoter: db.prepare("INSERT OR IGNORE INTO promoters(user_id) VALUES (?)"),
  getPromoter: db.prepare("SELECT * FROM promoters WHERE user_id=?"),
  setAccounts: db.prepare("UPDATE promoters SET account1=?, account2=? WHERE user_id=?"),
  setGoal: db.prepare("UPDATE promoters SET goal_views=COALESCE(?,goal_views), goal_posts=COALESCE(?,goal_posts), goal_invites=COALESCE(?,goal_invites) WHERE user_id=?"),
  addSubmission: db.prepare("INSERT INTO submissions(user_id,account,video_url,views) VALUES (?,?,?,?)"),
  getSubmission: db.prepare("SELECT * FROM submissions WHERE id=?"),
  pending: db.prepare("SELECT * FROM submissions WHERE status='pending' ORDER BY id LIMIT 20"),
  review: db.prepare("UPDATE submissions SET status=?, reviewed_by=?, reviewed_at=CURRENT_TIMESTAMP WHERE id=? AND status='pending'"),
  approved: db.prepare("SELECT COALESCE(SUM(views),0) AS views, COUNT(*) AS posts FROM submissions WHERE user_id=? AND status='approved' AND date(submitted_at) >= date('now','start of month')"),
  approvedAll: db.prepare("SELECT user_id, SUM(views) AS views, COUNT(*) AS posts FROM submissions WHERE status='approved' AND date(submitted_at) >= date('now','start of month') GROUP BY user_id"),
  getInvite: db.prepare("SELECT * FROM invite_codes WHERE code=? AND active=1"),
  addInvite: db.prepare("INSERT OR REPLACE INTO invite_codes(code,user_id,active) VALUES (?,?,1)"),
  deactivateInvite: db.prepare("UPDATE invite_codes SET active=0 WHERE code=?"),
  addUse: db.prepare("INSERT OR IGNORE INTO invite_uses(code,joined_user_id) VALUES (?,?)"),
  inviteCount: db.prepare("SELECT COUNT(*) AS n FROM invite_uses u JOIN invite_codes i ON i.code=u.code WHERE i.user_id=? AND date(u.joined_at)>=date('now','start of month')"),
  inviteCounts: db.prepare("SELECT i.user_id, COUNT(*) AS n FROM invite_uses u JOIN invite_codes i ON i.code=u.code WHERE date(u.joined_at)>=date('now','start of month') GROUP BY i.user_id"),
  setViews: db.prepare("INSERT INTO submissions(user_id,account,video_url,views,status,reviewed_by,reviewed_at) VALUES (?,'manual-adjustment','https://discord.com',?,'approved',?,CURRENT_TIMESTAMP)"),
  reset: db.prepare("DELETE FROM submissions WHERE date(submitted_at) < date('now','start of month')")
};

const inviteCache = new Map();

function ensureUser(id) {
  q.promoter.run(id);
  return q.getPromoter.get(id);
}
function isStaff(interaction) {
  if (interaction.memberPermissions?.has("Administrator")) return true;
  const roles = interaction.member?.roles?.cache;
  return !!roles && config.staffRoleIds.some(id => roles.has(id));
}
function pct(value, goal) {
  return goal > 0 ? Math.min(100, Math.round(value / goal * 100)) : 0;
}
function progressEmbed(user, memberLabel) {
  const p = ensureUser(user);
  const totals = q.approved.get(user);
  const invites = q.inviteCount.get(user).n;
  const goals = [
    `**Views:** ${totals.views.toLocaleString()} / ${p.goal_views.toLocaleString()} (${pct(totals.views,p.goal_views)}%)`,
    `**Posts:** ${totals.posts.toLocaleString()} / ${p.goal_posts.toLocaleString()} (${pct(totals.posts,p.goal_posts)}%)`,
    `**Invites:** ${invites.toLocaleString()} / ${p.goal_invites.toLocaleString()} (${pct(invites,p.goal_invites)}%)`
  ];
  return new EmbedBuilder().setColor(0x5865F2).setTitle(`${memberLabel || "Promoter"} · Monthly progress`)
    .setDescription(goals.join("\n"))
    .addFields(
      { name: "TikTok accounts", value: `1. ${p.account1 || "Not registered"}\n2. ${p.account2 || "Not registered"}`, inline: false },
      { name: "Quota note", value: "Only staff-approved submissions count toward views and posts.", inline: false }
    ).setTimestamp();
}
async function log(guild, message) {
  if (!config.logChannelId) return;
  const channel = await guild.channels.fetch(config.logChannelId).catch(() => null);
  if (channel?.isTextBased()) channel.send({ content: message }).catch(() => {});
}
async function reply(interaction, content, ephemeral=true) {
  const payload = { content, flags: ephemeral ? MessageFlags.Ephemeral : undefined };
  if (interaction.deferred || interaction.replied) return interaction.followUp(payload);
  return interaction.reply(payload);
}

client.once(Events.ClientReady, async c => {
  console.log(`Logged in as ${c.user.tag}`);
  for (const guild of c.guilds.cache.values()) {
    try {
      const invites = await guild.invites.fetch();
      inviteCache.set(guild.id, new Map(invites.map(i => [i.code, i.uses || 0])));
    } catch (e) { console.warn(`Could not cache invites for ${guild.id}: ${e.message}`); }
  }
});

client.on(Events.InviteCreate, invite => {
  const cache = inviteCache.get(invite.guild.id) || new Map();
  cache.set(invite.code, invite.uses || 0);
  inviteCache.set(invite.guild.id, cache);
});
client.on(Events.InviteDelete, invite => {
  q.deactivateInvite.run(invite.code);
  const cache = inviteCache.get(invite.guild.id);
  if (cache) cache.delete(invite.code);
});
client.on(Events.GuildMemberAdd, async member => {
  try {
    const before = inviteCache.get(member.guild.id) || new Map();
    const current = await member.guild.invites.fetch();
    let used = null;
    for (const inv of current.values()) {
      if ((inv.uses || 0) > (before.get(inv.code) || 0)) { used = inv; break; }
    }
    inviteCache.set(member.guild.id, new Map(current.map(i => [i.code, i.uses || 0])));
    if (used) {
      const tracked = q.getInvite.get(used.code);
      if (tracked) {
        q.addUse.run(used.code, member.id);
        await log(member.guild, `Tracked invite: <@${tracked.user_id}> referred <@${member.id}> using \`${used.code}\`.`);
      }
    }
  } catch (e) { console.warn("Invite tracking failed:", e.message); }
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;
  try {
    const user = interaction.user.id;
    ensureUser(user);

    if (interaction.commandName === "accounts") {
      const p = ensureUser(user);
      const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require("discord.js");
      const modal = new ModalBuilder().setCustomId("accounts_modal").setTitle("Register TikTok accounts");
      const a1 = new TextInputBuilder().setCustomId("account1").setLabel("TikTok username or profile URL (account 1)").setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(100).setValue(p.account1 || "");
      const a2 = new TextInputBuilder().setCustomId("account2").setLabel("TikTok username or profile URL (account 2)").setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(100).setValue(p.account2 || "");
      modal.addComponents(new ActionRowBuilder().addComponents(a1), new ActionRowBuilder().addComponents(a2));
      return interaction.showModal(modal);
    }

    if (interaction.commandName === "progress") return interaction.reply({ embeds: [progressEmbed(user, interaction.user.username)], flags: MessageFlags.Ephemeral });

    if (interaction.commandName === "goal") {
      const views = interaction.options.getInteger("views");
      const posts = interaction.options.getInteger("posts");
      const invites = interaction.options.getInteger("invites");
      if (views === null && posts === null && invites === null) return reply(interaction, "Provide at least one target: `views`, `posts`, or `invites`.");
      q.setGoal.run(views, posts, invites, user);
      return reply(interaction, "Your monthly targets have been updated. Use `/progress` to see your quota.");
    }

    if (interaction.commandName === "leaderboard") {
      const by = interaction.options.getString("by") || "invites";
      const totals = new Map(q.approvedAll.all().map(x => [x.user_id, x.views || 0]));
      const invites = new Map(q.inviteCounts.all().map(x => [x.user_id, x.n || 0]));
      const ids = new Set([...totals.keys(), ...invites.keys()]);
      const ranked = [...ids].map(id => ({ id, value: by === "views" ? (totals.get(id)||0) : (invites.get(id)||0) }))
        .sort((a,b) => b.value-a.value).slice(0,10);
      if (!ranked.length) return reply(interaction, "No promoter activity has been recorded this month.", false);
      const lines = await Promise.all(ranked.map(async (r,i) => {
        const member = await interaction.guild.members.fetch(r.id).catch(() => null);
        return `**${i+1}.** ${member?.displayName || "Former member"} — ${r.value.toLocaleString()} ${by}`;
      }));
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(0xF1C40F).setTitle(`Promo leaderboard · ${by}`).setDescription(lines.join("\n"))] });
    }

    if (interaction.commandName === "newinvite") {
      const invite = await interaction.channel.createInvite({ maxAge: 0, maxUses: 0, unique: true, reason: `Personal promo invite for ${user}` });
      q.addInvite.run(invite.code, user);
      return reply(interaction, `Your permanent personal invite is ready: ${invite.url}\nNew joins through this link will count toward your invite total. Keep using this link; older links remain tracked.`, true);
    }

    if (interaction.commandName === "staff") {
      const message = interaction.options.getString("message", true);
      const content = `**Staff message from** ${interaction.user.tag} (<@${user}>)\n${message}`;
      if (config.staffChannelId) {
        const ch = await interaction.guild.channels.fetch(config.staffChannelId).catch(() => null);
        if (!ch?.isTextBased()) return reply(interaction, "The configured staff channel is unavailable. Please contact an administrator.");
        await ch.send({ content });
      } else {
        const staffMembers = await interaction.guild.members.fetch();
        const targets = staffMembers.filter(m => config.staffRoleIds.some(id => m.roles.cache.has(id)));
        for (const m of targets.values()) await m.send(content).catch(() => {});
      }
      return reply(interaction, "Your message has been sent to staff.");
    }

    if (interaction.commandName === "submit") {
      const p = ensureUser(user);
      const slot = interaction.options.getString("account", true);
      const account = slot === "1" ? p.account1 : p.account2;
      if (!account) return reply(interaction, `Register TikTok account ${slot} first using \`/accounts\`.`);
      const url = interaction.options.getString("video_url", true);
      if (!/^https?:\/\/(www\.)?(tiktok\.com|vm\.tiktok\.com)\//i.test(url)) return reply(interaction, "Please provide a valid TikTok video URL.");
      const views = interaction.options.getInteger("views", true);
      const result = q.addSubmission.run(user, slot, url, views);
      await log(interaction.guild, `New pending submission #${result.lastInsertRowid} from <@${user}>: ${views.toLocaleString()} views.`);
      return reply(interaction, `Submission **#${result.lastInsertRowid}** received for ${account}. Staff must approve it before it counts toward your quota.`);
    }

    if (interaction.commandName === "admin") {
      if (!isStaff(interaction)) return reply(interaction, "You need the configured staff role or Administrator permission to use this command.");
      const sub = interaction.options.getSubcommand();
      if (sub === "pending") {
        const rows = q.pending.all();
        if (!rows.length) return reply(interaction, "There are no pending submissions.");
        return reply(interaction, rows.map(r => `**#${r.id}** · <@${r.user_id}> · Account ${r.account} · ${r.views.toLocaleString()} views\n${r.video_url}`).join("\n\n"));
      }
      if (sub === "approve" || sub === "reject") {
        const id = interaction.options.getInteger("id", true);
        const row = q.getSubmission.get(id);
        if (!row || row.status !== "pending") return reply(interaction, "That submission does not exist or has already been reviewed.");
        q.review.run(sub === "approve" ? "approved" : "rejected", user, id);
        const member = await interaction.guild.members.fetch(row.user_id).catch(() => null);
        if (member) await member.send(`Your TikTok submission **#${id}** was ${sub === "approve" ? "approved" : "rejected"}.`).catch(() => {});
        await log(interaction.guild, `Submission #${id} ${sub}d by <@${user}>.`);
        return reply(interaction, `Submission #${id} ${sub}d.`);
      }
      if (sub === "setviews") {
        const member = interaction.options.getUser("member", true);
        const views = interaction.options.getInteger("views", true);
        q.setViews.run(member.id, views, user);
        return reply(interaction, `Added a staff-approved adjustment of ${views.toLocaleString()} views for <@${member.id}>.`);
      }
      if (sub === "quota") {
        const member = interaction.options.getUser("member", true);
        const views = interaction.options.getInteger("views");
        const posts = interaction.options.getInteger("posts");
        const invites = interaction.options.getInteger("invites");
        if (views === null && posts === null && invites === null) return reply(interaction, "Provide at least one quota value.");
        ensureUser(member.id);
        q.setGoal.run(views, posts, invites, member.id);
        return reply(interaction, `Updated quota for <@${member.id}>.`);
      }
      if (sub === "member") {
        const member = interaction.options.getUser("member", true);
        return interaction.reply({ embeds: [progressEmbed(member.id, member.username)], flags: MessageFlags.Ephemeral });
      }
      if (sub === "removeaccount") {
        const member = interaction.options.getUser("member", true);
        const slot = interaction.options.getInteger("slot", true);
        const p = ensureUser(member.id);
        q.setAccounts.run(slot === 1 ? null : p.account1, slot === 2 ? null : p.account2, member.id);
        return reply(interaction, `Removed account ${slot} for <@${member.id}>.`);
      }
      if (sub === "reset") {
        db.prepare("DELETE FROM submissions WHERE date(submitted_at) >= date('now','start of month')").run();
        db.prepare("DELETE FROM invite_uses WHERE date(joined_at) >= date('now','start of month')").run();
        return reply(interaction, "Monthly approved view/post and invite totals have been reset. Registered accounts and goals were preserved.");
      }
    }
  } catch (error) {
    console.error(error);
    await reply(interaction, "Something went wrong. Please try again or contact staff.").catch(() => {});
  }
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isModalSubmit() || interaction.customId !== "accounts_modal") return;
  try {
    const user = interaction.user.id;
    const p = ensureUser(user);
    const a1 = interaction.fields.getTextInputValue("account1").trim() || null;
    const a2 = interaction.fields.getTextInputValue("account2").trim() || null;
    q.setAccounts.run(a1, a2, user);
    await interaction.reply({ content: "Your TikTok accounts have been saved. Submit videos with `/submit`.", flags: MessageFlags.Ephemeral });
  } catch (e) {
    console.error(e);
    if (!interaction.replied) await interaction.reply({ content: "Could not save your accounts. Contact staff.", flags: MessageFlags.Ephemeral });
  }
});

client.login(config.token);
